// Eksik Var — örnek veriler + yardımcılar
import { C } from "./theme";
// Not: Supabase bağlantısı yapılana kadar uygulama bu verilerle çalışır.

export const CITIES = ["Ankara", "İstanbul", "İzmir", "Bursa"];

export const CATEGORIES = [
  { id: 1, name: "Halı Saha", icon: "⚽" },
  { id: 2, name: "Basketbol", icon: "🏀" },
  { id: 3, name: "Voleybol", icon: "🏐" },
  { id: 4, name: "Tenis", icon: "🎾" },
];

// İletişim tercihleri: mode = ikisi | mesaj | arama, scope = herkes | kadro
export const DEFAULT_CONTACT = {
  mode: "ikisi", scope: "herkes",
  quiet: { enabled: false, start: "22:00", end: "08:00" },
};
export const DEFAULT_SETTINGS = {
  contact: DEFAULT_CONTACT,
  notif: { basvuru: true, mesaj: true, hatirlatma: true },
};
export const MODE_LABEL = { ikisi: "Mesaj ve arama açık", mesaj: "Yalnızca mesaj", arama: "Yalnızca arama" };

export const ORGS = {
  ali:    { id: "ali",    name: "Ali Yılmaz",    username: "ali_kaptan", rating: 4.8, count: 34, rel: 96,
            contact: { mode: "ikisi", scope: "herkes", quiet: { enabled: false, start: "22:00", end: "08:00" } } },
  zeynep: { id: "zeynep", name: "Zeynep Arslan", username: "zeynepa",    rating: 4.9, count: 51, rel: 98,
            contact: { mode: "mesaj", scope: "herkes", quiet: { enabled: false, start: "22:00", end: "08:00" } } },
  murat:  { id: "murat",  name: "Murat Şahin",   username: "murat07",    rating: 4.2, count: 9,  rel: 78,
            contact: { mode: "ikisi", scope: "kadro",  quiet: { enabled: true,  start: "23:00", end: "08:00" } } },
  ozan:   { id: "ozan",   name: "Ozan Demir",    username: "ozandmr",    rating: 4.5, count: 21, rel: 90,
            contact: { mode: "arama", scope: "herkes", quiet: { enabled: false, start: "22:00", end: "08:00" } } },
};

export const SEED_EVENTS = [
  {
    id: "e0", title: "Salı Halı Saha", cat: 1, city: "Ankara", district: "Çankaya",
    venue: "Yıldız Halı Saha, Çankaya", date: "Dün · 21:00", price: 150,
    capacity: 12, needed: 2, filled: 2, level: "Orta", status: "doldu",
    org: null, joined: false, mine: true, ended: true, attendance: null,
    desc: "Dün oynandı. Yoklamayı alıp maçı tamamla; gelmeyenleri işaretle.",
  },
  {
    id: "e8", title: "Cuma Halı Saha", cat: 1, city: "Ankara", district: "Çankaya",
    venue: "GoldSaha, Kızılay", date: "Geçen Cuma · 22:00", price: 150,
    capacity: 14, needed: 2, filled: 2, level: "Orta", status: "tamamlandi",
    org: ORGS.zeynep, joined: true, mine: false, ended: true,
    myAttendance: "katildi", attendance: { me: "katildi" },
    desc: "Tamamlandı. Zeynep yoklamayı aldı; katıldın olarak işaretlendin.",
  },
  {
    id: "e1", title: "Çarşamba Halı Saha", cat: 1, city: "Ankara", district: "Çankaya",
    venue: "Yıldız Halı Saha, Çankaya", date: "Çar · 21:00", price: 150,
    capacity: 14, needed: 3, filled: 2, level: "Orta", status: "acik",
    org: ORGS.ali, joined: false, mine: false, needs: { kaleci: 1, defans: 1, orta: 1 }, filledPos: { defans: 1, orta: 1 },
    desc: "Her hafta oynayan sıkı bir ekibiz, bu hafta 3 kişi eksiğiz. Kaleci öncelikli! Saha ücreti çıkışta bölüşülür.",
  },
  {
    id: "e2", title: "Pazar Ligi Maçı", cat: 1, city: "Ankara", district: "Keçiören",
    venue: "Arena Spor Tesisleri, Keçiören", date: "Paz · 18:00", price: 120,
    capacity: 12, needed: 2, filled: 0, level: "Farketmez", status: "acik",
    org: null, joined: false, mine: true,
    recurrence: "haftalik", seriesId: "e2", weekday: 0, time: "18:00", recurrenceUntil: null, needs: { defans: 1, orta: 1 }, filledPos: {},
    desc: "Pazar ligimizin bu haftaki maçı için 2 oyuncu arıyoruz. Stoper ve orta saha eksik.",
  },
  {
    id: "e3", title: "3x3 Sokak Basketbolu", cat: 2, city: "İstanbul", district: "Maltepe",
    venue: "Maltepe Sahil Sahası", date: "Cmt · 16:00", price: 0,
    capacity: 6, needed: 2, filled: 1, level: "Başlangıç", status: "acik",
    org: ORGS.zeynep, joined: false, mine: false,
    desc: "Rahat tempolu 3x3 maçı, yeni başlayanlar da gelebilir. Top bizden.",
  },
  {
    id: "e4", title: "Karışık Voleybol Akşamı", cat: 3, city: "İzmir", district: "Karşıyaka",
    venue: "Bostanlı Spor Salonu", date: "Per · 20:00", price: 80,
    capacity: 12, needed: 4, filled: 1, level: "Orta", status: "acik",
    org: ORGS.ozan, joined: false, mine: false, needs: { libero: 1 }, filledPos: { smacor: 1 },
    desc: "Karışık takım, file boyu standart. Salona uygun spor ayakkabı zorunlu.",
  },
  {
    id: "e5", title: "Tenis Eşleşmesi", cat: 4, city: "Bursa", district: "Nilüfer",
    venue: "Nilüfer Kort 2", date: "Cum · 19:00", price: 200,
    capacity: 2, needed: 1, filled: 0, level: "İleri", status: "acik",
    org: ORGS.zeynep, joined: false, mine: false,
    desc: "Tek maç için rakip arıyorum, ileri seviye. Kort ücreti yarı yarıya.",
  },
  {
    id: "e9", title: "Kızılay Akşam Basketi", cat: 2, city: "Ankara", district: "Çankaya",
    venue: "Kurtuluş Parkı Sahası", date: "Per · 20:00", price: 0,
    capacity: 10, needed: 3, filled: 1, level: "Orta", status: "acik",
    org: ORGS.ozan, joined: false, mine: false, needs: { guard: 1 }, filledPos: { pivot: 1 },
    desc: "Açık hava 5x5, top bizden. Yağmur yağarsa ertelenir.",
  },
  {
    id: "e10", title: "Etimesgut Halı Saha", cat: 1, city: "Ankara", district: "Etimesgut",
    venue: "Eryaman Spor Kompleksi", date: "Cmt · 19:00", price: 130,
    capacity: 14, needed: 2, filled: 0, level: "Başlangıç", status: "acik",
    org: ORGS.murat, joined: false, mine: false,
    desc: "Rahat tempolu maç, yeni başlayanlar da gelsin.",
  },
  {
    id: "e11", title: "Çankaya Cuma Maçı", cat: 1, city: "Ankara", district: "Çankaya",
    venue: "Ayrancı Halı Saha", date: "Cum · 21:30", price: 160,
    capacity: 14, needed: 1, filled: 0, level: "İleri", status: "acik",
    org: ORGS.ali, joined: false, mine: false, needs: { defans: 1 }, filledPos: {},
    desc: "Sıkı bir maç, bir stoper arıyoruz.",
  },
  {
    id: "e12", title: "Cumartesi Halı Saha", cat: 1, city: "Ankara", district: "Çankaya",
    venue: "Bilkent Spor Sahası", date: "Cmt · 20:00", price: 140,
    capacity: 14, needed: 2, filled: 2, level: "Orta", status: "doldu",
    org: ORGS.ozan, joined: false, mine: false, needs: { kaleci: 1 }, filledPos: { kaleci: 1, forvet: 1 },
    waitlistCount: 1, myWaitlist: false,
    desc: "Kadro doldu ama ayrılan olursa yedekten çağırırız. Yedek listesine gir!",
  },
  {
    id: "r1", kind: "rakip", title: "7v7 rakip · Cumartesi 20:00", cat: 1, city: "Ankara", district: "Çankaya",
    venue: "Yıldız Halı Saha", date: "Cmt · 20:00", price: 0, teamName: "Çankaya Yıldızları", format: "7v7", venueMode: "bizde", costMode: "yari_yariya",
    capacity: 7, needed: 1, filled: 0, level: "Orta", status: "acik", org: ORGS.ali, joined: false, mine: false,
    desc: "Her hafta oynayan sıkı ekibiz, bu Cumartesi rakibimiz yok. Saha bizde, ücret yarı yarıya, sertliğe gelemeyen gelmesin :)",
  },
  {
    id: "r2", kind: "rakip", title: "6v6 rakip · Pazar 21:00", cat: 1, city: "Ankara", district: "Etimesgut",
    venue: "", date: "Paz · 21:00", price: 0, teamName: "Etimesgut Boğaları", format: "6v6", venueMode: "sizde", costMode: "yari_yariya",
    capacity: 6, needed: 1, filled: 0, level: "Başlangıç", status: "acik", org: ORGS.murat, joined: false, mine: false,
    desc: "Yeni kurulan ekibiz, rahat tempolu maç istiyoruz. Sahayı siz ayarlarsanız geliriz.",
  },
  {
    id: "r3", kind: "rakip", title: "7v7 rakip · Cuma 22:00", cat: 1, city: "Ankara", district: "Keçiören",
    venue: "Arena Spor Tesisleri", date: "Cum · 22:00", price: 0, teamName: "Keçiören Kartalları", format: "7v7", venueMode: "bizde", costMode: "yari_yariya",
    capacity: 7, needed: 1, filled: 0, level: "Orta", status: "acik", org: null, joined: false, mine: true,
    desc: "Cuma gecesi rakip arıyoruz, saha bizde, ücret yarı yarıya.",
  },
  {
    id: "e6", title: "Cuma Akşam Maçı", cat: 1, city: "İstanbul", district: "Kadıköy",
    venue: "GoldSaha, Kadıköy", date: "Cum · 22:00", price: 170,
    capacity: 14, needed: 2, filled: 2, level: "Orta", status: "doldu",
    org: ORGS.ali, joined: false, mine: false, waitlistCount: 3,
    desc: "Kadro tamamlandı, iyi maçlar!",
  },
];

/* ---------- kadro üyeleri ---------- */
const NAME_POOL = ["Burak Çelik", "Kerem Aydın", "Serkan Öz", "Tolga Kılıç", "Can Yıldırım", "Mert Doğan",
  "Halil Koç", "Yusuf Akın", "Barış Erdem", "Onur Taş", "Emir Sarı", "Deniz Kurt", "Furkan Aslan",
  "Kaan Polat", "Eren Güneş", "Umut Bulut", "Arda Şen", "Cem Yavuz", "Hakan Tekin", "Selim Ateş"];
const slug = (name) => name.toLowerCase().replace(/ç/g, "c").replace(/ğ/g, "g").replace(/ı/g, "i")
  .replace(/ö/g, "o").replace(/ş/g, "s").replace(/ü/g, "u").replace(/\s+/g, "_");
const hash = (str) => { let h = 7; for (const ch of String(str)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };

// ORGS kaydından üye nesnesi (role: organizator | uye · via: ekip | uygulama)
export const memberFromOrg = (o, role = "uye", via = "ekip") =>
  ({ id: o.id, name: o.name, username: o.username, rating: o.rating, count: o.count, rel: o.rel, role, via });

// Mevcut ekip için deterministik örnek üyeler (aynı seed → aynı isimler)
export function genMembers(n, seed, via = "ekip") {
  const out = [];
  const start = hash(seed) % NAME_POOL.length;
  for (let i = 0; i < Math.max(0, n); i++) {
    const name = NAME_POOL[(start + i) % NAME_POOL.length];
    const h = hash(seed + name + i);
    out.push({
      id: `u-${slug(name)}-${i}-${h % 97}`, name, username: slug(name) + (10 + (h % 90)),
      rating: +(3.9 + (h % 12) / 10).toFixed(1), count: 5 + (h % 40), rel: 82 + (h % 18), role: "uye", via,
    });
  }
  return out;
}

export const SEED_CHATS = [
  {
    id: "g-r3", type: "grup", eventId: "r3", title: "Keçiören Kartalları · kaptanlar", sub: "1 üye",
    unread: 0, lastTime: "Dün", members: [{ id: "me", role: "organizator", via: "ekip" }],
    msgs: [{ id: "s1", from: "sys", text: "Kaptanlar sohbeti · Rakip takımın kaptanı kabul edilince buraya eklenir", time: "Dün" }],
  },
  {
    id: "g-e0", type: "grup", eventId: "e0", title: "Salı Halı Saha", sub: "12 üye",
    unread: 0, lastTime: "Dün",
    members: [{ id: "me", role: "organizator", via: "ekip" }, memberFromOrg(ORGS.murat, "uye", "uygulama"),
              memberFromOrg(ORGS.ozan, "uye", "uygulama"), ...genMembers(9, "e0")],
    msgs: [
      { id: "s1", from: "sys", text: "Maç dün 21:00'de oynandı · Yoklama bekleniyor", time: "Dün" },
      { id: "m1", from: "ozan", name: "Ozan Demir", text: "İyi maçtı, haftaya aynı saat mi?", time: "Dün" },
    ],
  },
  {
    id: "g-e2", type: "grup", eventId: "e2", title: "Pazar Ligi Maçı", sub: "11 üye",
    unread: 0, lastTime: "14:02",
    members: [{ id: "me", role: "organizator", via: "ekip" }, memberFromOrg(ORGS.ozan), ...genMembers(9, "e2")],
    msgs: [
      { id: "s1", from: "sys", text: "Grubu oluşturdun · Onaylanan oyuncular buraya eklenir", time: "12:40" },
      { id: "m1", from: "ozan", name: "Ozan Demir", text: "Bu hafta forma beyaz mı hocam?", time: "13:58" },
      { id: "m2", from: "me", text: "Beyaz getirin, rakip koyu giyiyor", time: "14:02" },
    ],
  },
  {
    id: "g-old", type: "grup", eventId: null, title: "Salı Basketbol Ekibi", sub: "8 üye",
    unread: 2, lastTime: "Dün",
    members: [{ id: "me", role: "uye", via: "uygulama" }, memberFromOrg(ORGS.zeynep, "organizator"),
              memberFromOrg(ORGS.ozan), ...genMembers(5, "old")],
    msgs: [
      { id: "s1", from: "sys", text: "Zeynep Arslan kadroya katıldı", time: "Dün" },
      { id: "m1", from: "zeynep", name: "Zeynep Arslan", text: "Salı 20:00 kesinleşti mi?", time: "Dün" },
      { id: "m2", from: "ozan", name: "Ozan Demir", text: "Kesin, salon onaylandı 👍", time: "Dün" },
    ],
  },
  {
    id: "dm-e11", type: "birebir", eventId: "e11", otherId: "ali", title: "Ali Yılmaz", sub: "\"Çankaya Cuma Maçı\" daveti",
    unread: 1, lastTime: "15:20",
    msgs: [
      { id: "s1", from: "sys", text: "Ali Yılmaz seni \"Çankaya Cuma Maçı\" kadrosuna davet etti. Kabul edersen yerin kesinleşir.", time: "15:20" },
      { id: "m1", from: "ali", name: "Ali Yılmaz", text: "Cuma stoper lazım, gelir misin? 🙏", time: "15:20" },
      { id: "ap", from: "approval", appId: "app-e11" },
    ],
  },
  {
    id: "dm-zeynep", type: "birebir", eventId: null, otherId: "zeynep", title: "Zeynep Arslan", sub: "",
    unread: 0, lastTime: "Cts",
    msgs: [
      { id: "m1", from: "zeynep", name: "Zeynep Arslan", text: "Geçen maç için tekrar teşekkürler 🙌", time: "Cts" },
      { id: "m2", from: "me", text: "Ben teşekkür ederim, yine bekleriz!", time: "Cts" },
    ],
  },
];

export const SEED_APPS = [
  { id: "a1", eventId: "e2", who: ORGS.murat, note: "Stoper oynarım hocam, ben varım", status: "beklemede", position: "defans" },
  { id: "app-e11", eventId: "e11", who: "me", note: "", status: "orgBekliyor", invited: true, position: "defans" },
  { id: "a-r3", eventId: "r3", who: { ...ORGS.ozan, teamName: "Kızılay Gücü" }, note: "7 kişiyiz, saha sizde olur, ücrete varız", status: "beklemede" },
];

export const MY_COMMENTS = [
  { from: "Ali Yılmaz", stars: 5, text: "Dakik ve centilmen, her maça alırım 👏" },
  { from: "Zeynep Arslan", stars: 5, text: "Takım oyununa katkısı süper" },
  { from: "Ozan Demir", stars: 4, text: "İyi maçtı, yine bekleriz" },
];

/* ---------- yardımcılar ---------- */
export const nowTime = () =>
  new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });

export const uid = () => Math.random().toString(36).slice(2, 9);

export const initials = (name) =>
  (name || "?").split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

const AVATAR_BG = ["#0B3D2E", "#1D5FBF", "#7C3AED", "#B4232A", "#B45309"];
export const avatarBg = (name) =>
  AVATAR_BG[((name || "?").charCodeAt(0) || 0) % AVATAR_BG.length];

const SENDER_COLOR = ["#0B6B3A", "#1D5FBF", "#7C3AED", "#B4232A", "#B45309"];
export const senderColor = (id) =>
  SENDER_COLOR[((id || "?").charCodeAt(0) || 0) % SENDER_COLOR.length];

/* ---------- iletişim izinleri ---------- */
export function inQuietHours(quiet, now = new Date()) {
  if (!quiet || !quiet.enabled) return false;
  const [sh, sm] = quiet.start.split(":").map(Number);
  const [eh, em] = quiet.end.split(":").map(Number);
  const cur = now.getHours() * 60 + now.getMinutes();
  const s = sh * 60 + sm, e = eh * 60 + em;
  return s <= e ? cur >= s && cur < e : cur >= s || cur < e; // gece yarısını aşan aralık
}

/* other: karşı tarafın kaydı · sharesSquad: aynı kadroda mıyız
   applicationChat: başvuru sohbeti mi (bunlar kapsam kısıtından muaf) */
export function contactRules(other, sharesSquad, applicationChat = false) {
  const c = (other && other.contact) || DEFAULT_CONTACT;
  const first = ((other && other.name) || "Bu kişi").split(" ")[0];
  const r = { canMessage: true, canCall: true, messageReason: null, callReason: null };
  if (c.mode === "arama") { r.canMessage = false; r.messageReason = `${first} yalnızca arama kabul ediyor`; }
  if (c.mode === "mesaj") { r.canCall = false; r.callReason = `${first} aramaları kapatmış`; }
  if (c.scope === "kadro" && !sharesSquad) {
    if (r.canCall) { r.canCall = false; r.callReason = `${first} yalnızca kadrosundakilerden arama alıyor`; }
    if (r.canMessage && !applicationChat) { r.canMessage = false; r.messageReason = `${first} yalnızca kadrosundakilerden mesaj alıyor`; }
  }
  if (r.canCall && inQuietHours(c.quiet)) {
    r.canCall = false; r.callReason = `${first} şu an sessiz saatlerde (${c.quiet.start}–${c.quiet.end})`;
  }
  return r;
}

/* ---------- yoklama & güvenilirlik ---------- */
// Örnek veri: 20 maçlık geçmiş varsayımıyla yeni yüzdeyi hesaplar (sunucuda gerçek sayaçlar kullanılır)
export const relAfterShow   = (rel) => Math.min(100, Math.round((((rel || 90) * 20) / 100 + 1) * 100 / 21));
export const relAfterNoShow = (rel) => Math.round(((rel || 90) * 20) / 21);

export const MY_ATTENDANCE = [
  { title: "Cuma Halı Saha",     date: "Geçen Cuma",    status: "katildi" },
  { title: "Salı Basketbol",     date: "2 hafta önce",  status: "katildi" },
  { title: "Perşembe Halı Saha", date: "3 hafta önce",  status: "gelmedi" },
  { title: "Pazar Ligi Maçı",    date: "1 ay önce",     status: "katildi" },
  { title: "Cuma Halı Saha",     date: "1 ay önce",     status: "katildi" },
];

/* ---------- tarih & tekrar yardımcıları ---------- */
export const GUNLER = ["Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt"];
export const GUNLER_UZUN = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
export const AYLAR = ["Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"];

const pad = (n) => String(n).padStart(2, "0");
export const toDateISO = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const addDays = (iso, n) => { const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return toDateISO(d); };

// Önümüzdeki n gün: [{ iso, label, weekday }] — bugün ve yarın özel etiketli
export function nextDates(n = 14) {
  const out = [];
  const today = new Date();
  for (let i = 0; i < n; i++) {
    const d = new Date(today); d.setDate(today.getDate() + i);
    const label = i === 0 ? "Bugün" : i === 1 ? "Yarın" : `${GUNLER[d.getDay()]} ${d.getDate()}`;
    out.push({ iso: toDateISO(d), label, weekday: d.getDay() });
  }
  return out;
}

export const TIMES = [];
for (let h = 8; h <= 23; h++) { TIMES.push(`${pad(h)}:00`); TIMES.push(`${pad(h)}:30`); }

// "Bugün · 21:00", "Yarın · 21:00", "Çar · 21:00" (7 gün içinde), "Çar 3 Eyl · 21:00"
export function fmtEventDate(iso, time) {
  const d = new Date(iso + "T12:00:00");
  const today = new Date(); today.setHours(12, 0, 0, 0);
  const diff = Math.round((d - today) / 86400000);
  const day = diff === 0 ? "Bugün" : diff === 1 ? "Yarın"
    : diff > 1 && diff < 7 ? GUNLER[d.getDay()] : `${GUNLER[d.getDay()]} ${d.getDate()} ${AYLAR[d.getMonth()]}`;
  return `${day} · ${time}`;
}

/* ---------- paylaşım ---------- */
// Not: eksikvar.app alan adı yayın aşamasında bağlanacak; o güne kadar link yer tutucu,
// mesajın kendisi WhatsApp'ta okunabilir. ?d= parametresi daveti kimin attığını taşır.
export const APP_LINK = "https://eksikvar.app";

export function buildShareText(ev, user) {
  const cat = CATEGORIES.find((c) => c.id === ev.cat);
  if (ev.kind === "rakip") {
    return [
      `🆚 Rakip arıyoruz · ${ev.teamName}`,
      `${cat ? cat.icon : "⚽"} ${ev.format} · ${ev.level} · ${ev.date}`,
      `📍 ${ev.venue || "Saha konuşulur"} · ${venueModeLabel(ev.venueMode)} · ${costModeLabel(ev.costMode)} · ${ev.district || ev.city}`,
      ``,
      `Teklif vermek için: ${APP_LINK}/e/${ev.id}?d=${user.username}`,
      ``,
      `Eksik Var · kadron eksik kalmasın`,
    ].join("\n");
  }
  const remaining = Math.max(0, ev.needed - ev.filled);
  const price = ev.price === 0 ? "Ücretsiz" : `${ev.price}₺/kişi`;
  const lines = [
    `${cat ? cat.icon : "⚽"} ${ev.title}`,
    `📍 ${ev.venue} · ${ev.city}`,
    `🗓 ${ev.date} · ${price}`,
    ev.recurrence === "haftalik" ? `🔁 Her ${GUNLER_UZUN[ev.weekday]}` : null,
    ``,
    remaining > 0 ? `👥 ${remaining} EKSİK VAR! Kadro ${ev.capacity} kişi, ${ev.capacity - remaining} hazır.` : `👥 Kadro tamam.`,
    `Başvurmak için: ${APP_LINK}/e/${ev.id}?d=${user.username}`,
    ``,
    `Eksik Var · kadron eksik kalmasın`,
  ];
  return lines.filter((l) => l !== null).join("\n");
}

export function buildInviteText(user) {
  return [
    `Selam! Halı saha / basket / voleybol için kadro tamamlama uygulaması kullanıyorum: Eksik Var.`,
    `"Bir kişi eksiğiz" mesajı yerine talep açıyorsun, gelenler başvuruyor, çift onayla kadro doluyor; kim güvenilir kim gelmiyor puanla belli.`,
    ``,
    `İndir: ${APP_LINK}?d=${user.username}`,
  ].join("\n");
}

/* ---------- ilçe sıralaması: en çok açık etkinliği olan önde, sonra alfabetik ---------- */
export function districtCounts(events, city) {
  const counts = {};
  events.forEach((e) => {
    if (e.city === city && e.status === "acik" && !e.ended && e.district) counts[e.district] = (counts[e.district] || 0) + 1;
  });
  return counts;
}
export function sortDistricts(districts, counts) {
  return [...districts].sort((a, b) => (counts[b] || 0) - (counts[a] || 0) || districts.indexOf(a) - districts.indexOf(b));
}

/* ---------- bildirimler ---------- */
export const NOTIF_META = {
  basvuru:    { icon: "person-add",          color: C.kit,     bg: C.kitSoft },
  onay:       { icon: "checkmark-circle",    color: C.pitch,   bg: C.pitchSoft },
  kadro:      { icon: "people",              color: C.pitch,   bg: C.pitchSoft },
  doldu:      { icon: "trophy",              color: C.turf,    bg: C.pitchSoft },
  mesaj:      { icon: "chatbubble-ellipses", color: "#1D5FBF", bg: "#E8F0FF" },
  hatirlatma: { icon: "alarm",               color: C.kit,     bg: C.kitSoft },
  yoklama:    { icon: "clipboard",           color: C.kit,     bg: C.kitSoft },
  puanlama:   { icon: "star",                color: "#C48A00", bg: "#FFF6D6" },
  tekrar:     { icon: "repeat",              color: C.turf,    bg: C.pitchSoft },
  red:        { icon: "close-circle",        color: C.faint,   bg: C.line },
  davet:      { icon: "mail-open",           color: C.pitch,   bg: C.pitchSoft },
  yedek:      { icon: "hourglass",           color: C.kit,     bg: C.kitSoft },
  etkinlik_iptal: { icon: "close-circle",    color: C.kit,     bg: C.kitSoft },
};

export const SEED_NOTIFS = [
  { id: "n0", type: "davet", title: "Ali seni kadroya davet etti", body: "Çankaya Cuma Maçı · Cum 21:30 · Defans", time: "15:20", read: false, data: { eventId: "e11", chatId: "dm-e11" } },
  { id: "n1", type: "basvuru", title: "Yeni başvuru", body: "Murat Şahin, Pazar Ligi Maçı için başvurdu: \"Stoper oynarım hocam, ben varım\"", time: "14:05", read: false, data: { eventId: "e2" } },
  { id: "n2", type: "yoklama", title: "Yoklama bekliyor", body: "Salı Halı Saha dün oynandı — gelmeyenleri işaretle, maçı tamamla", time: "09:00", read: false, data: { attendanceId: "e0" } },
  { id: "n3", type: "puanlama", title: "Cuma Halı Saha tamamlandı", body: "Zeynep Arslan'ı ve takım arkadaşlarını puanla", time: "Cts", read: false, data: { rate: true, eventId: "e8" } },
  { id: "n4", type: "hatirlatma", title: "Maç 2 saat sonra", body: "Cuma Halı Saha · GoldSaha, Kızılay · 22:00", time: "Cum", read: true, data: { eventId: "e8" } },
  { id: "n5", type: "mesaj", title: "Ozan Demir · Pazar Ligi Maçı", body: "Bu hafta forma beyaz mı hocam?", time: "Cum", read: true, data: { chatId: "g-e2" } },
];

/* ---------- şikayet & puanlama ---------- */
export const REPORT_REASONS = [
  { label: "Taciz veya hakaret", id: "taciz" },
  { label: "Sahte etkinlik / yanlış bilgi", id: "sahte_etkinlik" },
  { label: "Sürekli gelmiyor", id: "gelmedi" },
  { label: "Dolandırıcılık / para", id: "dolandiricilik" },
  { label: "Diğer", id: "diger" },
];
// yeni puanla güncellenen ortalama (ekranda gösterim için)
export const applyRating = (m, stars) => {
  const count = (m.count || 0) + 1;
  const rating = +((((m.rating || 0) * (m.count || 0)) + stars) / count).toFixed(1);
  return { ...m, rating, count };
};
// maça kaç saat kaldı (tarih bilinmiyorsa null)
export const hoursUntil = (ev) => {
  if (!ev.dateISO || !ev.time) return null;
  return (new Date(`${ev.dateISO}T${ev.time}:00`) - new Date()) / 3600000;
};

/* ---------- telefon numarası ---------- */
// "0532 123 45 67", "532...", "+90 532..." → "+905321234567" (Türkiye cep); geçersizse null
export function normalizePhone(input) {
  let d = String(input || "").replace(/\D/g, "");
  if (d.startsWith("0090")) d = d.slice(4);
  else if (d.startsWith("90") && d.length === 12) d = d.slice(2);
  else if (d.startsWith("0") && d.length === 11) d = d.slice(1);
  if (d.length !== 10 || d[0] !== "5") return null;
  return "+90" + d;
}
export const formatPhone = (e164) => {
  const d = String(e164 || "").replace(/\D/g, "").slice(-10);
  return d.length === 10 ? `0${d.slice(0, 3)} ${d.slice(3, 6)} ${d.slice(6, 8)} ${d.slice(8)}` : e164;
};

/* ---------- başkalarının aldığı yorumlar (örnek) ---------- */
const CURATED_COMMENTS = {
  ali:    [{ from: "Zeynep Arslan", stars: 5, text: "Organizasyonu tıkır tıkır, saha hep hazır", event: "Çarşamba Halı Saha" },
           { from: "Ozan Demir", stars: 5, text: "Kadro dağılmıyor, her hafta aynı saat", event: "Çarşamba Halı Saha" },
           { from: "Kerem Aydın", stars: 4, text: "Ücreti çıkışta topluyor, düzenli", event: "Cuma Akşam Maçı" }],
  zeynep: [{ from: "Ali Yılmaz", stars: 5, text: "Dakik ve centilmen, her maça alırım", event: "Cuma Halı Saha" },
           { from: "Deniz Kurt", stars: 5, text: "Takım oyununa katkısı süper", event: "Salı Basketbol" },
           { from: "Burak Çelik", stars: 5, text: "Hakem gibi adil", event: "Cuma Halı Saha" }],
  murat:  [{ from: "Ali Yılmaz", stars: 3, text: "Son dakika iptal etti, kadro açık kaldı", event: "Pazar Ligi Maçı" },
           { from: "Serkan Öz", stars: 5, text: "İyi stoper, sert ama temiz", event: "Etimesgut Halı Saha" }],
  ozan:   [{ from: "Emre Kaya", stars: 4, text: "İyi maçtı, yine bekleriz", event: "Pazar Ligi Maçı" },
           { from: "Zeynep Arslan", stars: 5, text: "Pozitif enerji, moral kaynağı", event: "Salı Basketbol" }],
};
const COMMENT_POOL = ["Dakik, sahaya ilk gelen", "İyi paslaşıyor, bencil değil", "Bir kez geç kaldı ama haber verdi", "Sert oyuncu, dikkat",
  "Kaleye geçmeyi kabul etti, eyvallah", "Her hafta gelen güvenilir isim", "Ücreti geç ödedi", "Sakin, hakemle tartışmıyor"];
export function commentsFor(member) {
  if (!member) return [];
  if (CURATED_COMMENTS[member.id]) return CURATED_COMMENTS[member.id];
  const h = hash(member.id); const n = 1 + (h % 3); const out = [];
  for (let i = 0; i < n; i++) {
    const k = (h + i * 7) % COMMENT_POOL.length;
    out.push({ from: NAME_POOL[(h + i * 3) % NAME_POOL.length], stars: 3 + ((h + i) % 3), text: COMMENT_POOL[k], event: i % 2 ? "Salı Halı Saha" : "Pazar Ligi Maçı" });
  }
  return out;
}

/* ---------- mevkiler ---------- */
export const POSITIONS = {
  1: [{ id: "kaleci", label: "Kaleci", icon: "🧤" }, { id: "defans", label: "Defans", icon: "🛡️" }, { id: "orta", label: "Orta saha", icon: "🔁" }, { id: "forvet", label: "Forvet", icon: "🎯" }],
  2: [{ id: "guard", label: "Guard", icon: "🏀" }, { id: "forvet_b", label: "Forvet", icon: "🏀" }, { id: "pivot", label: "Pivot", icon: "🏀" }],
  3: [{ id: "pasor", label: "Pasör", icon: "🏐" }, { id: "smacor", label: "Smaçör", icon: "🏐" }, { id: "orta_v", label: "Orta oyuncu", icon: "🏐" }, { id: "libero", label: "Libero", icon: "🏐" }],
};
export const ALL_POSITIONS = Object.values(POSITIONS).flat();
export const posLabel = (id) => (id === "farketmez" ? "Farketmez" : (ALL_POSITIONS.find((p) => p.id === id) || { label: id }).label);
export const posIcon = (id) => (ALL_POSITIONS.find((p) => p.id === id) || { icon: "•" }).icon;

// ev.needs = {mevki: kota}, ev.filledPos = {mevki: dolu}; serbest kontenjan = needed - kotalar
export function positionSlots(ev) {
  const needs = ev.needs || {}; const filledPos = ev.filledPos || {};
  const specified = Object.values(needs).reduce((a, b) => a + Number(b), 0);
  const free = Math.max(0, (ev.needed || 0) - specified);
  const freeUsed = Object.entries(filledPos).filter(([p]) => !(p in needs)).reduce((a, [, v]) => a + Number(v), 0);
  const slots = Object.entries(needs).map(([id, quota]) => ({ id, label: posLabel(id), icon: posIcon(id), quota: Number(quota), filled: Number(filledPos[id] || 0) }));
  if (free > 0) slots.push({ id: "farketmez", label: "Farketmez", icon: "•", quota: free, filled: freeUsed });
  return slots;
}
export const openPositions = (ev) => positionSlots(ev).filter((s) => s.filled < s.quota);
export function needsSummary(ev) {
  const open = openPositions(ev).filter((s) => s.id !== "farketmez");
  return open.length ? open.map((s) => `${s.icon} ${s.quota - s.filled} ${s.label.toLowerCase()}`).join(" · ") : null;
}
export const matchesMyPositions = (ev, mine) => openPositions(ev).some((s) => s.id === "farketmez" || (mine || []).includes(s.id));
export const positionAvailable = (ev, pos) => { const s = positionSlots(ev).find((x) => x.id === (pos || "farketmez")); return s ? s.filled < s.quota : openPositions(ev).some((x) => x.id === "farketmez"); };

/* ---------- rakip bul ---------- */
export const FORMATS = ["5v5", "6v6", "7v7", "8v8", "11v11"];
export const VENUE_MODES = [["bizde", "Saha bizde"], ["sizde", "Saha sizde"], ["farketmez", "Farketmez"]];
export const COST_MODES = [["yari_yariya", "Ücret yarı yarıya"], ["biz", "Biz karşılarız"], ["siz", "Siz karşılarsınız"]];
export const venueModeLabel = (m) => (VENUE_MODES.find(([id]) => id === m) || [null, "Saha konuşulur"])[1];
export const costModeLabel = (m) => (COST_MODES.find(([id]) => id === m) || [null, "Ücret konuşulur"])[1];
export const isRakip = (ev) => ev.kind === "rakip";
export const teamLabel = (who) => (who && (who.teamName || who.name)) || "Takım";
