import React from "react";
import { View, Text, TouchableOpacity, ScrollView, TextInput, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { C } from "../theme";
import { CATEGORIES, GUNLER_UZUN, positionSlots, posLabel, posIcon, venueModeLabel, costModeLabel, teamLabel, VARMISIN_OPTIONS, PAYMENT_LABEL, paymentSummary, formatLabel, relInfo, relColor } from "../data";
import { Avatar, Stars, SquadDots, EksikBadge } from "../components";

export default function EventDetailScreen({
  ev, apps, myApp, roster, onBack, onApply, onApprove, onReject, onGoChat, onAttendance, onDispute, onShare,
  onEdit = () => {}, onCancel = () => {}, onLeave = () => {}, onRate = () => {}, rated = false, onOrganizer = () => {},
  onAcceptInvite = () => {}, onDeclineInvite = () => {}, onJoinWaitlist = () => {}, onLeaveWaitlist = () => {},
  availability = null, onAskAvailability = () => {}, onApplySuggested = () => {}, onAnswer = () => {},
  onRecordScore = () => {}, myMvpVote = null,
  onClaimPayment = () => {}, onConfirmPayment = () => {}, onSendIban = () => {}, onRemindPayments = () => {},
}) {
  const payList = ev.payments || [];
  const showPay = ev.price > 0 && ev.status !== "iptal" && ((ev.mine && payList.length > 0) || (!ev.mine && !!ev.myPayment));
  const [sh, setSh] = React.useState(""); const [sa, setSa] = React.useState("");
  const av = availability;
  const showAv = !!av && ev.status !== "iptal" && ev.status !== "tamamlandi" && !ev.ended && ev.kind !== "rakip";
  const pendingInvite = myApp && myApp.invited && myApp.status === "orgBekliyor";
  const rakip = ev.kind === "rakip";
  const pendingOffer = pendingInvite && myApp.fromWaitlist;
  const canWaitlist = !ev.mine && !ev.joined && !myApp && !ev.ended && ev.status === "doldu";
  const shareable = ev.status === "acik" && ev.needed - ev.filled > 0;
  const manageable = ev.mine && !ev.ended && ev.status !== "iptal" && ev.status !== "tamamlandi";
  const canRate = ev.status === "tamamlandi" && (ev.joined || ev.mine);
  const marks = ev.attendance || {};
  const noShows = (roster || []).filter((m) => marks[m.id] === "gelmedi");
  const attended = (roster || []).filter((m) => marks[m.id] === "katildi");
  const cat = CATEGORIES.find((c) => c.id === ev.cat);
  const remaining = ev.needed - ev.filled;
  const eventApps = apps.filter((a) => a.eventId === ev.id && a.who !== "me");

  return (
    <View style={{ flex: 1, backgroundColor: C.chalk }}>
      <View style={st.header}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <TouchableOpacity onPress={onBack} style={st.back}>
            <Ionicons name="chevron-back" size={18} color={C.mist} />
            <Text style={{ color: C.mist, fontWeight: "700", fontSize: 13 }}>Geri</Text>
          </TouchableOpacity>
          {shareable && (
            <TouchableOpacity onPress={() => onShare(ev)} style={st.shareBtn}>
              <Ionicons name="share-social-outline" size={16} color="#fff" />
              <Text style={{ color: "#fff", fontWeight: "800", fontSize: 12 }}>Paylaş</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
          <View style={{ flex: 1, paddingRight: 10 }}>
            <Text style={{ fontSize: 22 }}>{cat?.icon}</Text>
            <Text style={st.title}>{ev.title}</Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
              <Ionicons name="location-outline" size={13} color={C.mist} />
              <Text style={{ color: C.mist, fontSize: 13, flexShrink: 1 }}>
                {ev.venue} · {ev.district ? `${ev.district}, ` : ""}{ev.city}
              </Text>
            </View>
          </View>
          <EksikBadge ev={ev} />
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: 140 }}>
        <View style={{ flexDirection: "row", gap: 8 }}>
          {(rakip ? [
            ["calendar-outline", ev.date],
            ["people-outline", `${formatLabel(ev.cat, ev.format)} · ${ev.level}`],
            ["cash-outline", costModeLabel(ev.costMode)],
          ] : [
            ["calendar-outline", ev.date],
            ["cash-outline", ev.price === 0 ? "Ücretsiz" : `${ev.price}₺/kişi`],
            ["trophy-outline", `${ev.level}${ev.format ? ` · ${formatLabel(ev.cat, ev.format)}` : ""}`],
          ]).map(([icon, text], i) => (
            <View key={i} style={st.infoBox}>
              <Ionicons name={icon} size={16} color={C.turf} />
              <Text style={{ fontSize: 11, fontWeight: "800", color: C.ink, marginTop: 3, textAlign: "center" }}>
                {text}
              </Text>
            </View>
          ))}
        </View>

        {rakip && (
          <View style={[st.card, { borderLeftWidth: 4, borderLeftColor: C.kit }]}>
            <Text style={st.cardTitle}>RAKİP ARAYAN TAKIM</Text>
            <Text style={{ fontSize: 18, fontWeight: "900", color: C.ink, marginTop: 6 }}>{ev.teamName}</Text>
            <Text style={{ fontSize: 13, color: C.faint, marginTop: 2 }}>
              {formatLabel(ev.cat, ev.format)} · {ev.level} · {venueModeLabel(ev.venueMode)}{ev.venue ? ` (${ev.venue})` : ""} · {costModeLabel(ev.costMode)}
            </Text>
            {ev.filled >= ev.needed && (
              <Text style={{ fontSize: 13, fontWeight: "800", color: C.pitch, marginTop: 8 }}>
                🆚 Maç ayarlandı · saha ve ücret detaylarını kaptanlar sohbetinde netleştirin
              </Text>
            )}
          </View>
        )}

        {!rakip && <View style={st.card}>
          <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
            <Text style={st.cardTitle}>KADRO DURUMU</Text>
            <Text style={{ fontSize: 12, fontWeight: "800", color: C.faint }}>
              {ev.capacity - remaining}/{ev.capacity}
            </Text>
          </View>
          <View style={{ marginTop: 10 }}>
            <SquadDots capacity={ev.capacity} needed={ev.needed} filled={ev.filled} size={13} />
          </View>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 12, marginTop: 10 }}>
            <View style={st.legend}>
              <View style={[st.dot, { backgroundColor: C.turf }]} />
              <Text style={st.legendText}>Mevcut ekip</Text>
            </View>
            <View style={st.legend}>
              <View style={[st.dot, { backgroundColor: C.pitch }]} />
              <Text style={st.legendText}>Uygulamadan ({ev.filled}/{ev.needed})</Text>
            </View>
            <View style={st.legend}>
              <View style={[st.dot, { borderWidth: 1.5, borderStyle: "dashed", borderColor: C.kit }]} />
              <Text style={st.legendText}>Eksik</Text>
            </View>
          </View>
        </View>}

        {ev.status === "iptal" && (
          <View style={[st.card, { borderWidth: 1.5, borderColor: C.line }]}>
            <Text style={st.cardTitle}>İPTAL EDİLDİ</Text>
            <Text style={{ fontSize: 13, color: C.ink, marginTop: 6, lineHeight: 19 }}>
              {ev.cancelReason ? `Sebep: ${ev.cancelReason}` : "Organizatör etkinliği iptal etti."} Kadrodakilere bildirildi.
            </Text>
          </View>
        )}

        {ev.ended && ev.status !== "iptal" && (
          <View style={[st.card, ev.status !== "tamamlandi" && ev.mine && { borderWidth: 1.5, borderColor: C.kit }]}>
            <Text style={st.cardTitle}>YOKLAMA</Text>
            {ev.mine && ev.status !== "tamamlandi" && (
              <Text style={{ fontSize: 13, color: C.ink, marginTop: 6, lineHeight: 19 }}>
                Maç oynandı, yoklama bekleniyor. Gelmeyenleri işaretleyip maçı tamamla; 48 saat içinde
                alınmazsa herkes katıldı sayılır.
              </Text>
            )}
            {ev.mine && ev.status === "tamamlandi" && (
              <View style={{ marginTop: 6 }}>
                <Text style={{ fontSize: 13, color: C.ink }}>
                  <Text style={{ fontWeight: "900", color: C.pitch }}>{attended.length} katıldı</Text>
                  {"  ·  "}
                  <Text style={{ fontWeight: "900", color: noShows.length ? C.kit : C.faint }}>{noShows.length} gelmedi</Text>
                </Text>
                {noShows.length > 0 && (
                  <Text style={{ fontSize: 12, color: C.faint, marginTop: 4 }}>
                    Gelmeyenler: {noShows.map((m) => m.name).join(", ")}
                  </Text>
                )}
              </View>
            )}
            {!ev.mine && ev.joined && (
              <View style={{ marginTop: 6 }}>
                {ev.myAttendance === "katildi" && (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Ionicons name="checkmark-circle" size={18} color={C.pitch} />
                    <Text style={{ fontSize: 13, fontWeight: "800", color: C.pitch }}>Katıldın · güvenilirliğin korundu</Text>
                  </View>
                )}
                {ev.myAttendance === "gelmedi" && (
                  <View>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                      <Ionicons name="close-circle" size={18} color={C.kit} />
                      <Text style={{ fontSize: 13, fontWeight: "800", color: C.kit }}>Gelmedi olarak işaretlendin</Text>
                    </View>
                    {ev.disputed ? (
                      <Text style={{ fontSize: 12, color: C.faint, marginTop: 6 }}>İtirazın iletildi, inceleniyor.</Text>
                    ) : (
                      <TouchableOpacity onPress={() => onDispute(ev.id)} style={st.disputeBtn}>
                        <Text style={{ fontSize: 12, fontWeight: "800", color: C.turf }}>Hatalı mı? İtiraz et</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                )}
                {!ev.myAttendance && (
                  <Text style={{ fontSize: 13, color: C.faint }}>Organizatör henüz yoklama almadı.</Text>
                )}
              </View>
            )}
          </View>
        )}

        {showPay && (
          <View style={st.card}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={st.cardTitle}>ÖDEMELER · {ev.price}₺/KİŞİ</Text>
              {ev.mine && (() => { const sm = paymentSummary(payList); return (
                <Text style={{ fontSize: 12, fontWeight: "800", color: sm.pending ? C.kit : C.pitch }}>{sm.paid}/{sm.total} ödendi{sm.pending ? ` · ${sm.pending}₺ bekliyor` : ""}</Text>
              ); })()}
            </View>
            {ev.mine ? (
              <View style={{ marginTop: 8 }}>
                <View style={{ flexDirection: "row", gap: 8, marginBottom: 8 }}>
                  <TouchableOpacity onPress={() => onSendIban(ev.id)} style={[st.btn, st.btnGhost, { flex: 1, paddingVertical: 10, flexDirection: "row", gap: 6 }]}>
                    <Ionicons name="card-outline" size={16} color={C.turf} /><Text style={[st.btnText, { color: C.turf }]}>IBAN'ı gruba gönder</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => onRemindPayments(ev.id)} style={[st.btn, { flex: 1, backgroundColor: C.kitSoft, paddingVertical: 10, flexDirection: "row", gap: 6 }]}>
                    <Ionicons name="notifications-outline" size={16} color={C.kit} /><Text style={[st.btnText, { color: C.kit }]}>Ödemeyenlere hatırlat</Text>
                  </TouchableOpacity>
                </View>
                {payList.map((p) => (
                  <View key={p.id} style={st.payRow}>
                    <Avatar name={p.name} uri={p.avatar} size={30} />
                    <View style={{ flex: 1, marginLeft: 8 }}>
                      <Text style={{ fontWeight: "800", fontSize: 13, color: C.ink }}>{p.name}</Text>
                      <Text style={{ fontSize: 11, color: p.status === "odedim" ? C.kit : C.faint }}>{p.amount}₺ · {PAYMENT_LABEL[p.status]}</Text>
                    </View>
                    {p.status === "odendi" || p.status === "muaf" ? (
                      <TouchableOpacity onPress={() => onConfirmPayment(ev.id, p.id, "bekliyor")} style={[st.payBtn, { backgroundColor: C.pitchSoft }]}>
                        <Text style={{ fontSize: 11, fontWeight: "800", color: C.turf }}>{p.status === "muaf" ? "Muaf" : "✓ Ödendi"}</Text>
                      </TouchableOpacity>
                    ) : (
                      <View style={{ flexDirection: "row", gap: 4 }}>
                        <TouchableOpacity onPress={() => onConfirmPayment(ev.id, p.id, "odendi")} style={[st.payBtn, { backgroundColor: p.status === "odedim" ? C.pitch : C.chalk }]}>
                          <Text style={{ fontSize: 11, fontWeight: "800", color: p.status === "odedim" ? "#fff" : C.turf }}>{p.status === "odedim" ? "Onayla" : "Ödendi"}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => onConfirmPayment(ev.id, p.id, "muaf")} style={[st.payBtn, { backgroundColor: C.chalk }]}>
                          <Text style={{ fontSize: 11, fontWeight: "800", color: C.faint }}>Muaf</Text>
                        </TouchableOpacity>
                      </View>
                    )}
                  </View>
                ))}
              </View>
            ) : (
              <View style={{ marginTop: 8 }}>
                <Text style={{ fontSize: 13, color: C.ink }}>
                  Saha ücretin: <Text style={{ fontWeight: "900" }}>{ev.myPayment.amount}₺</Text> · <Text style={{ fontWeight: "800", color: ev.myPayment.status === "odendi" ? C.pitch : ev.myPayment.status === "odedim" ? C.kit : C.faint }}>{PAYMENT_LABEL[ev.myPayment.status]}</Text>
                </Text>
                {ev.myPayment.status === "bekliyor" && (
                  <TouchableOpacity onPress={() => onClaimPayment(ev.id)} style={[st.cta, { backgroundColor: C.turf, marginTop: 10 }]}>
                    <Text style={st.ctaText}>Ödedim · organizatöre bildir</Text>
                  </TouchableOpacity>
                )}
                {ev.myPayment.status === "odedim" && <Text style={{ fontSize: 12, color: C.faint, marginTop: 6 }}>Organizatör onaylayınca "Ödendi" olur.</Text>}
              </View>
            )}
          </View>
        )}

        {ev.status === "tamamlandi" && (
          <View style={[st.card, { borderWidth: 1.5, borderColor: "#F5B301" }]}>
            <Text style={st.cardTitle}>MAÇ SONUCU</Text>
            {ev.score ? (
              <View style={{ marginTop: 6 }}>
                <Text style={{ fontSize: 26, fontWeight: "900", color: C.ink }}>{ev.score.home} – {ev.score.away}</Text>
                <Text style={{ fontSize: 12, color: C.faint }}>{ev.score.label}</Text>
              </View>
            ) : ev.mine ? (
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8 }}>
                <TextInput value={sh} onChangeText={setSh} keyboardType="number-pad" placeholder={ev.kind === "rakip" ? "Biz" : "Yelekliler"} placeholderTextColor="#9AA79F" style={st.scoreInput} maxLength={2} />
                <Text style={{ fontSize: 18, fontWeight: "900", color: C.faint }}>–</Text>
                <TextInput value={sa} onChangeText={setSa} keyboardType="number-pad" placeholder={ev.kind === "rakip" ? "Rakip" : "Yeleksizler"} placeholderTextColor="#9AA79F" style={st.scoreInput} maxLength={2} />
                <TouchableOpacity disabled={sh === "" || sa === ""} onPress={() => onRecordScore(ev.id, Number(sh), Number(sa))} style={[st.btn, { backgroundColor: C.turf, paddingHorizontal: 14, paddingVertical: 10 }, (sh === "" || sa === "") && { opacity: 0.4 }]}>
                  <Text style={[st.btnText, { color: "#fff" }]}>Kaydet</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <Text style={{ fontSize: 13, color: C.faint, marginTop: 6 }}>Organizatör skoru henüz girmedi.</Text>
            )}
            <View style={{ marginTop: 10, flexDirection: "row", alignItems: "center", gap: 8 }}>
              <Text style={{ fontSize: 18 }}>🏆</Text>
              <View style={{ flex: 1 }}>
                {ev.mvp ? (
                  <Text style={{ fontSize: 13, color: C.ink }}>
                    <Text style={{ fontWeight: "900" }}>{ev.mvp.final ? "Maçın oyuncusu: " : "Önde: "}{ev.mvp.name}</Text> · {ev.mvp.votes} oy{ev.mvp.final ? "" : " · oylama sürüyor"}
                  </Text>
                ) : (
                  <Text style={{ fontSize: 13, color: C.faint }}>MVP oylaması sürüyor — puanlama ekranından oy ver.</Text>
                )}
                {myMvpVote && <Text style={{ fontSize: 11, color: C.faint }}>Oyunu verdin.</Text>}
              </View>
            </View>
          </View>
        )}

        {showAv && (
          <View style={[st.card, { borderLeftWidth: 4, borderLeftColor: C.pitch }]}>
            <Text style={st.cardTitle}>BU HAFTA VAR MISIN?</Text>
            {!av.asked ? (
              <View style={{ marginTop: 6 }}>
                <Text style={{ fontSize: 13, color: C.faint, lineHeight: 18 }}>
                  Sabit kadroya henüz sorulmadı; maça 72 saat kala sistem kendisi sorar, cevap vermeyenlere 24 saat kala hatırlatır.
                </Text>
                {ev.mine && (
                  <TouchableOpacity onPress={() => onAskAvailability(ev.id)} style={[st.btn, st.btnGhost, { alignSelf: "flex-start", marginTop: 10, paddingHorizontal: 14 }]}>
                    <Text style={[st.btnText, { color: C.turf }]}>Şimdi sor</Text>
                  </TouchableOpacity>
                )}
              </View>
            ) : (
              <View style={{ marginTop: 8 }}>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                  {[["✅", av.varim, "varım", C.pitch], ["❌", av.yokum, "yokum", C.kit], ["🤔", av.belirsiz, "belli değil", C.faint], ["⏳", av.cevapsiz, "cevapsız", C.faint]].map(([ic, n, l, col]) => (
                    <View key={l} style={st.avChip}><Text style={{ fontSize: 12, fontWeight: "900", color: col }}>{ic} {n} {l}</Text></View>
                  ))}
                </View>
                {!ev.mine && (
                  <View style={{ flexDirection: "row", gap: 6, marginTop: 10 }}>
                    {VARMISIN_OPTIONS.map((o) => (
                      <TouchableOpacity key={o.id} onPress={() => onAnswer(ev.id, o.id)}
                        style={[st.avAnswer, av.myAnswer === o.id && { backgroundColor: C.turf, borderColor: C.turf }]}>
                        <Text style={{ fontSize: 12, fontWeight: "800", color: av.myAnswer === o.id ? "#fff" : C.ink }}>{o.text}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
                {ev.mine && (
                  <View style={{ marginTop: 10 }}>
                    <Text style={{ fontSize: 13, color: C.ink }}>
                      Kadro hesabı: {ev.capacity} kişilik, {ev.offlineRegulars || 0} uygulama dışı sabit oyuncu, {av.varim} "varım"
                      {" "}→ önerilen eksik <Text style={{ fontWeight: "900", color: av.suggested !== ev.needed ? C.kit : C.pitch }}>{av.suggested}</Text> (şu an {ev.needed})
                    </Text>
                    {av.suggested !== ev.needed && (
                      <TouchableOpacity onPress={() => onApplySuggested(ev.id)} style={[st.cta, { backgroundColor: C.kit, marginTop: 10 }]}>
                        <Text style={st.ctaText}>Eksiği {av.suggested} yap · kadroya duyur</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                )}
              </View>
            )}
          </View>
        )}

        {positionSlots(ev).some((sl) => sl.id !== "farketmez") && (
          <View style={st.card}>
            <Text style={st.cardTitle}>ARANAN MEVKİLER</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
              {positionSlots(ev).map((sl) => {
                const done = sl.filled >= sl.quota;
                return (
                  <View key={sl.id} style={[st.posChip, done && { backgroundColor: C.pitchSoft, borderColor: C.pitchSoft }]}>
                    <Text style={{ fontSize: 13, fontWeight: "800", color: done ? C.pitch : C.ink }}>
                      {sl.icon} {sl.label} {sl.filled}/{sl.quota}{done ? " ✓" : ""}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        <View style={st.card}>
          <Text style={st.cardTitle}>AÇIKLAMA</Text>
          <Text style={{ fontSize: 14, color: C.ink, lineHeight: 21, marginTop: 6 }}>{ev.desc}</Text>
          {ev.recurrence === "haftalik" && (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 10, backgroundColor: C.pitchSoft, borderRadius: 10, padding: 10 }}>
              <Ionicons name="repeat" size={16} color={C.turf} />
              <Text style={{ flex: 1, fontSize: 12, color: C.turf, fontWeight: "700", lineHeight: 17 }}>
                Her {GUNLER_UZUN[ev.weekday]} {ev.time || ""} tekrar eder. Maç bitince gelecek hafta otomatik açılır; ekip grubu aynı kalır.
              </Text>
            </View>
          )}
        </View>

        {!ev.mine && (
          <TouchableOpacity onPress={() => onOrganizer(ev.org)} style={[st.card, { flexDirection: "row", alignItems: "center", gap: 12 }]}>
            <Avatar name={ev.org.name} uri={ev.org.avatar} size={44} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: "800", color: C.ink, fontSize: 14 }}>{ev.org.name}</Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 2 }}>
                <Stars value={ev.org.rating} size={12} />
                <Text style={{ fontWeight: "800", fontSize: 12, color: C.ink }}>{ev.org.rating}</Text>
                <Text style={{ fontSize: 12, color: C.faint }}>({ev.org.count} puan)</Text>
              </View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 3, marginTop: 2 }}>
                <Ionicons name="shield-checkmark" size={12} color={C.pitch} />
                <Text style={{ fontSize: 12, fontWeight: "700", color: C.pitch }}>
                  {relInfo(ev.org).text} güvenilirlik
                </Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={18} color={C.gray} />
          </TouchableOpacity>
        )}

        {ev.mine && ev.waitlist && ev.waitlist.length > 0 && (
          <View style={st.card}>
            <Text style={st.cardTitle}>YEDEKLER ({ev.waitlist.length})</Text>
            {ev.waitlist.map((w, i) => (
              <View key={w.id || i} style={{ flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 6 }}>
                <Text style={{ fontSize: 12, fontWeight: "900", color: C.faint, width: 18 }}>{i + 1}.</Text>
                <Text style={{ flex: 1, fontSize: 13, fontWeight: "700", color: C.ink }}>{w.name}</Text>
                <Text style={{ fontSize: 12, color: C.faint }}>{w.position ? `${posIcon(w.position)} ${posLabel(w.position)}` : "Farketmez"}</Text>
              </View>
            ))}
            <Text style={{ fontSize: 11, color: C.faint, marginTop: 4 }}>Yer açılınca sıradaki yedeğe 2 saatlik onay teklifi gider.</Text>
          </View>
        )}

        {ev.mine && (
          <View style={st.card}>
            <Text style={st.cardTitle}>{rakip ? "RAKİP TEKLİFLERİ" : "BAŞVURULAR"} ({eventApps.length})</Text>
            {eventApps.length === 0 && (
              <Text style={{ color: C.faint, fontSize: 13, marginTop: 6 }}>
                {rakip ? "Henüz teklif yok — ilan yayında, rakip takımlar burada listelenecek." : "Henüz başvuru yok — talep yayında, gelenler burada listelenecek."}
              </Text>
            )}
            {eventApps.map((a) => (
              <View key={a.id} style={st.appRow}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                  <Avatar name={a.who.name} size={38} />
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: "800", fontSize: 13, color: C.ink }}>{rakip ? `${teamLabel(a.who)} · ${a.who.name.split(" ")[0]}` : a.who.name}</Text>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 2, flexWrap: "wrap" }}>
                      <Stars value={a.who.rating} size={11} />
                      <Text style={{ fontSize: 11, color: C.faint }}>{a.who.rating}</Text>
                      {a.who.rel < 85 ? (
                        <View style={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
                          <Ionicons name="warning" size={11} color={C.kit} />
                          <Text style={{ fontSize: 11, fontWeight: "800", color: C.kit }}>
                            {relInfo(a.who).text} güvenilirlik
                          </Text>
                        </View>
                      ) : (
                        <View style={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
                          <Ionicons name="shield-checkmark" size={11} color={C.pitch} />
                          <Text style={{ fontSize: 11, fontWeight: "700", color: C.pitch }}>{relInfo(a.who).text}</Text>
                        </View>
                      )}
                    </View>
                  </View>
                </View>
                {a.position && (
                  <View style={{ flexDirection: "row", marginTop: 6 }}>
                    <View style={st.posChip}><Text style={{ fontSize: 12, fontWeight: "800", color: C.ink }}>{posIcon(a.position)} {posLabel(a.position)}</Text></View>
                  </View>
                )}
                <Text style={st.note}>"{a.note}"</Text>
                {a.status === "beklemede" && (
                  <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
                    <TouchableOpacity onPress={() => onApprove(a.id)} style={[st.btn, { backgroundColor: C.pitch }]}>
                      <Text style={st.btnText}>Onayla</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => onReject(a.id)} style={[st.btn, st.btnGhost]}>
                      <Text style={[st.btnText, { color: C.faint }]}>Reddet</Text>
                    </TouchableOpacity>
                  </View>
                )}
                {a.status === "orgBekliyor" && (
                  <Text style={{ fontSize: 12, fontWeight: "800", color: C.kit, marginTop: 8 }}>
                    {a.invited ? `Davet ettin · ${a.who.name.split(" ")[0]}'ın cevabı bekleniyor…` : `Onayladın · ${a.who.name.split(" ")[0]}'ın son onayı bekleniyor…`}
                  </Text>
                )}
                {a.status === "onaylandi" && (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 8 }}>
                    <Ionicons name="checkmark" size={14} color={C.pitch} />
                    <Text style={{ fontSize: 12, fontWeight: "900", color: C.pitch }}>
                      Kadroda — grup sohbetine eklendi
                    </Text>
                  </View>
                )}
                {a.status === "reddedildi" && (
                  <Text style={{ fontSize: 12, fontWeight: "700", color: C.faint, marginTop: 8 }}>Reddedildi</Text>
                )}
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      {manageable && (
        <View style={st.bottomBar}>
          {shareable && (
            <TouchableOpacity onPress={() => onShare(ev)} style={[st.cta, st.waBtn, { marginBottom: 8 }]}>
              <Ionicons name="logo-whatsapp" size={20} color="#fff" />
              <Text style={st.ctaText}>WhatsApp grubuna at · {ev.needed - ev.filled} eksik</Text>
            </TouchableOpacity>
          )}
          <View style={{ flexDirection: "row", gap: 8 }}>
            <TouchableOpacity onPress={() => onEdit(ev.id)} style={[st.btn, st.btnGhost, { paddingVertical: 12, flexDirection: "row", gap: 6 }]}>
              <Ionicons name="create-outline" size={16} color={C.turf} />
              <Text style={[st.btnText, { color: C.turf }]}>Düzenle</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => onCancel(ev.id)} style={[st.btn, st.btnGhost, { paddingVertical: 12, flexDirection: "row", gap: 6 }]}>
              <Ionicons name="close-circle-outline" size={16} color={C.danger} />
              <Text style={[st.btnText, { color: C.danger }]}>İptal et</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {canRate && (
        <View style={st.bottomBar}>
          {rated ? (
            <View style={[st.cta, { backgroundColor: C.pitchSoft }]}>
              <Text style={[st.ctaText, { color: C.turf }]}>Puanladın ✓ Teşekkürler</Text>
            </View>
          ) : (
            <TouchableOpacity onPress={() => onRate(ev.id)} style={[st.cta, { backgroundColor: C.turf, flexDirection: "row", justifyContent: "center", gap: 8 }]}>
              <Ionicons name="star" size={16} color={C.star} />
              <Text style={st.ctaText}>Takım arkadaşlarını puanla</Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      {ev.mine && ev.ended && ev.status !== "tamamlandi" && (
        <View style={st.bottomBar}>
          <TouchableOpacity onPress={() => onAttendance(ev.id)} style={[st.cta, { backgroundColor: C.kit }]}>
            <Text style={st.ctaText}>Yoklama al ve maçı tamamla</Text>
          </TouchableOpacity>
        </View>
      )}

      {!ev.mine && !canRate && ev.status !== "iptal" && (
        <View style={st.bottomBar}>
          {ev.joined ? (
            <View style={{ flexDirection: "row", gap: 8 }}>
              <TouchableOpacity onPress={() => onGoChat("g-" + ev.id)} style={[st.cta, { backgroundColor: C.turf, flex: 1 }]}>
                <Text style={st.ctaText}>Grup sohbetine git</Text>
              </TouchableOpacity>
              {!ev.ended && (
                <TouchableOpacity onPress={() => onLeave(ev.id)} style={[st.cta, st.btnGhost, { paddingHorizontal: 14 }]}>
                  <Text style={[st.ctaText, { color: C.danger }]}>Ayrıl</Text>
                </TouchableOpacity>
              )}
            </View>
          ) : pendingInvite ? (
            <View>
              <Text style={{ textAlign: "center", fontSize: 13, fontWeight: "800", color: pendingOffer ? C.kit : C.turf, marginBottom: 8 }}>
                {pendingOffer
                  ? `Yer açıldı! ${myApp.offerExpiresAt ? myApp.offerExpiresAt + "'ye kadar" : "Süresi içinde"} onayla${myApp.position ? ` · ${posLabel(myApp.position)}` : ""}`
                  : `${ev.org ? ev.org.name.split(" ")[0] : "Organizatör"} seni kadroya davet etti${myApp.position ? ` · ${posLabel(myApp.position)}` : ""}`}
              </Text>
              <View style={{ flexDirection: "row", gap: 8 }}>
                <TouchableOpacity onPress={() => onAcceptInvite(myApp.id)} style={[st.cta, { backgroundColor: C.pitch, flex: 1 }]}>
                  <Text style={st.ctaText}>{pendingOffer ? "Yerimi onayla" : "Daveti kabul et"}</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => onDeclineInvite(myApp.id)} style={[st.cta, st.btnGhost, { paddingHorizontal: 16 }]}>
                  <Text style={[st.ctaText, { color: C.danger }]}>Reddet</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : myApp ? (
            <TouchableOpacity onPress={() => onGoChat("dm-" + ev.id)} style={[st.cta, { backgroundColor: C.pitchSoft }]}>
              <Text style={[st.ctaText, { color: C.turf }]}>Başvurun iletildi · Sohbete git</Text>
            </TouchableOpacity>
          ) : ev.myWaitlist ? (
            <View style={{ flexDirection: "row", gap: 8 }}>
              <View style={[st.cta, { backgroundColor: C.kitSoft, flex: 1 }]}>
                <Text style={[st.ctaText, { color: C.kit }]}>Yedek listesindesin ⏳ {ev.waitlistCount ? `· ${ev.waitlistCount} yedek` : ""}</Text>
              </View>
              <TouchableOpacity onPress={() => onLeaveWaitlist(ev.id)} style={[st.cta, st.btnGhost, { paddingHorizontal: 14 }]}>
                <Text style={[st.ctaText, { color: C.faint }]}>Ayrıl</Text>
              </TouchableOpacity>
            </View>
          ) : canWaitlist ? (
            <TouchableOpacity onPress={() => onJoinWaitlist(ev.id)} style={[st.cta, { backgroundColor: C.kit }]}>
              <Text style={st.ctaText}>Yedek ol{ev.waitlistCount ? ` · ${ev.waitlistCount} yedek bekliyor` : ""}</Text>
            </TouchableOpacity>
          ) : ev.status === "doldu" ? (
            <View style={[st.cta, { backgroundColor: C.turf, opacity: 0.5 }]}>
              <Text style={st.ctaText}>Kadro tamamlandı</Text>
            </View>
          ) : (
            <TouchableOpacity onPress={onApply} style={[st.cta, { backgroundColor: C.pitch }]}>
              <Text style={st.ctaText}>
                {rakip ? "Rakip ol · teklif gönder" : `Başvur${ev.price > 0 ? ` · ${ev.price}₺/kişi` : ""}`}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </View>
  );
}

const st = StyleSheet.create({
  header: { backgroundColor: C.turf, paddingHorizontal: 18, paddingTop: 10, paddingBottom: 18 },
  back: { flexDirection: "row", alignItems: "center" },
  shareBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 999, paddingHorizontal: 12, paddingVertical: 6,
  },
  waBtn: { backgroundColor: "#25D366", flexDirection: "row", justifyContent: "center", gap: 8 },
  title: { color: "#fff", fontSize: 22, fontWeight: "900", marginTop: 4 },
  infoBox: {
    flex: 1, backgroundColor: "#fff", borderRadius: 14, paddingVertical: 12,
    alignItems: "center", justifyContent: "center",
  },
  card: { backgroundColor: "#fff", borderRadius: 16, padding: 14, marginTop: 12 },
  cardTitle: { fontSize: 11, fontWeight: "900", letterSpacing: 0.8, color: C.turf },
  legend: { flexDirection: "row", alignItems: "center", gap: 4 },
  legendText: { fontSize: 11, fontWeight: "600", color: C.faint },
  dot: { width: 10, height: 10, borderRadius: 5 },
  appRow: { borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 12, marginTop: 10 },
  note: {
    backgroundColor: C.chalk, borderRadius: 10, padding: 10, marginTop: 8,
    fontSize: 13, fontStyle: "italic", color: C.ink,
  },
  btn: { flex: 1, borderRadius: 12, alignItems: "center", paddingVertical: 9 },
  btnGhost: { backgroundColor: "#fff", borderWidth: 1, borderColor: C.line },
  btnText: { color: "#fff", fontWeight: "800", fontSize: 13 },
  posChip: { borderWidth: 1, borderColor: C.line, backgroundColor: "#fff", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 },
  payRow: { flexDirection: "row", alignItems: "center", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.line },
  payBtn: { borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 },
  scoreInput: { width: 64, borderWidth: 1, borderColor: C.line, borderRadius: 10, paddingVertical: 8, textAlign: "center", fontSize: 18, fontWeight: "900", color: C.ink, backgroundColor: "#fff" },
  avChip: { backgroundColor: C.chalk, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 },
  avAnswer: { flex: 1, alignItems: "center", borderWidth: 1, borderColor: C.line, backgroundColor: "#fff", borderRadius: 10, paddingVertical: 9 },
  disputeBtn: {
    alignSelf: "flex-start", backgroundColor: C.chalk, borderRadius: 999,
    paddingHorizontal: 12, paddingVertical: 7, marginTop: 8,
  },
  bottomBar: {
    position: "absolute", bottom: 0, left: 0, right: 0,
    backgroundColor: "#fff", borderTopWidth: 1, borderTopColor: C.line, padding: 14,
  },
  cta: { borderRadius: 14, alignItems: "center", paddingVertical: 14 },
  ctaText: { color: "#fff", fontWeight: "900", fontSize: 14 },
});
